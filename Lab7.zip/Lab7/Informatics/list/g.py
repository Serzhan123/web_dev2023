n = int(input())
arr = list(map(int, input().split())) 
cnt = 0

for i in reversed(arr):
    print(i, end=" ")

