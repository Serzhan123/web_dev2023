n = int(input())

i = 0

while 2 ** i <= n:
    print(2 ** i, end=" ")
    i += 1

# n = int(input())
# i = 1
# w
# hile n > = 2**i:
#     i += 1
#     print((i-1), 2**(i-1))