import math
 
print("YES" if math.log(int(input()), 2).is_integer() else "NO")
