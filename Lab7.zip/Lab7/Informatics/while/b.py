n = int(input())
i = 2
while n % i != 0:
    i += 1
print(i)