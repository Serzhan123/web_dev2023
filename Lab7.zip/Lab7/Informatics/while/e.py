n = int(input())
sum = 1
k = 0
while n > sum:
    sum *= 2
    k += 1
print(k)