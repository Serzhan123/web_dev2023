n = int(input())

i = 0

while i <= n:
    if i ** 2 < n and i >= 1:
        print(i ** 2)
    i += 1