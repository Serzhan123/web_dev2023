a = int(input())
b = int(input())

print(b // a)