n = int(input())

mes = f'''The next number for the number {n} is {n + 1}.
The previous number for the number {n} is {n - 1}.'''

print(mes)