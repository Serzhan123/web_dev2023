import math as m

a = int(input())
b = int(input())

print(float(m.sqrt(a ** 2 + b ** 2)))