arr = [int(value) for value in input().split()]
print(sum(arr))