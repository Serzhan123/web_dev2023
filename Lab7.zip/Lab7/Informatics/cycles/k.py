n = int(input())

res = 0
for i in range(n):
    val = int(input())
    res += val

print(res)