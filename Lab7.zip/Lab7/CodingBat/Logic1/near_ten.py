def near_ten(num):
    num_mod_10 = num % 10
    return  num_mod_10 <= 2 or num_mod_10 >= 8
