def double_char(str):
  res = ''
  for i in str:
    res += i * 2
    
  return res
