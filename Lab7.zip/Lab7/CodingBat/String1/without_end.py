def without_end(str):
  return str[1:-1]
