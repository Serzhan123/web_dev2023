def left2(str):
  s = str[:2]
  return str[2:] + s
