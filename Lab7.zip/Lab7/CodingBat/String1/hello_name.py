def hello_name(name):
  str = 'Hello '
  str2 = '!'
  return str + name + str2
