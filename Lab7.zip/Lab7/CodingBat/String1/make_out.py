def make_out_word(out, word):
  start = out[:2]
  end = out[2:]
  return start + word + end
