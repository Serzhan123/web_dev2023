def middle_way(a, b):
  arr = []
  arr.append(a[1])
  arr.append(b[1])
  return arr
