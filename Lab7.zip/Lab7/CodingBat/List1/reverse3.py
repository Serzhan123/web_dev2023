def reverse3(nums):
  arr = []
  arr.append(nums[-1])
  arr.append(nums[1])
  arr.append(nums[0])
  return arr
