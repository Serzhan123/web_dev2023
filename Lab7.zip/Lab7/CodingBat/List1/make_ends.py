def make_ends(nums):
  arr = []
  arr.append(nums[0])
  arr.append(nums[-1])
  
  return arr
