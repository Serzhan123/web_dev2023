def front_times(str, n):
  s = str[:3]
  return s * n
