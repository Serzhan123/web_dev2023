def sum_double(a, b):
  if a == b:
    return 2 * (a + b)
  return a + b
