def front3(str):
  s = str[:3]
  return s * 3
