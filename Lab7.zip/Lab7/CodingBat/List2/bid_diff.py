def big_diff(nums):
  return max(nums) - min(nums)
