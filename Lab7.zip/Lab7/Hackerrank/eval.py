# Enter your code here. Read input from STDIN. Print output to STDOUT
var = input()

eval(var)